import * as React from "react";
import {
  Text,
  StyleSheet,
  View,
  ImageBackground,
  Pressable,
} from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontFamily, FontSize } from "../GlobalStyles";

const Page2giiThiuApp = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <Pressable
      style={styles.page2giiThiuApp}
      onPress={() => navigation.navigate("NhnBitSCu")}
    >
      <ImageBackground
        style={styles.icon}
        resizeMode="cover"
        source={require("../assets/page2giithiuapp.png")}
      >
        
      </ImageBackground>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  textLayout: {
    flexDirection: "row",
    height: 27,
    width: 258,
    position: "absolute",
  },
  viperTypo: {
    alignItems: "center",
    display: "flex",
    color: Color.colorWhite,
    fontFamily: FontFamily.rasaBold,
    fontWeight: "700",
    lineHeight: 20,
    letterSpacing: 0,
    height: 27,
  },
  viperLayout: {
    width: 288,
    position: "absolute",
  },
  niCThTypo: {
    fontSize: FontSize.size_11xl,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.rasaBold,
    fontWeight: "700",
    lineHeight: 20,
    letterSpacing: 0,
    height: 27,
  },
  choMngBn: {
    fontSize: 32,
    width: 329,
    textAlign: "left",
    display: "flex",
    color: Color.colorWhite,
    fontFamily: FontFamily.rasaBold,
    fontWeight: "700",
    lineHeight: 20,
    letterSpacing: 0,
  },
  text: {
    top: 221,
    left: 68,
  },
  viper: {
    marginLeft: -144,
    top: 362,
    left: "50%",
    fontSize: 96,
    textAlign: "center",
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    color: Color.colorWhite,
    fontFamily: FontFamily.rasaBold,
    fontWeight: "700",
    lineHeight: 20,
    letterSpacing: 0,
    height: 27,
    width: 288,
  },
  niCTh: {
    top: 509,
    left: 98,
    width: 288,
    position: "absolute",
  },
  phnBitCc: {
    width: 329,
  },
  text1: {
    top: 558,
    left: 83,
  },
  icon: {
    flex: 1,
    height: "100%",
    overflow: "hidden",
    width: "100%",
  },
  page2giiThiuApp: {
    height: 917,
    width: "100%",
  },
});

export default Page2giiThiuApp;
