import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { Color, FontFamily, FontSize, Border, Gap } from "../GlobalStyles";

const NhnBitSCu1 = () => {
  return (
    <View style={styles.nhnBitSCu2}>
      <View style={styles.button1Parent}>
        <LinearGradient
          style={styles.button1}
          locations={[0, 1]}
          colors={["#fefae0", "#fb8500"]}
        >
          <Text style={[styles.sCu, styles.sCuLayout]}>{`Sơ cứu `}</Text>
          <Image
            style={[styles.knowledgeSharingIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/knowledge-sharing1.png")}
          />
        </LinearGradient>
        <LinearGradient
          style={styles.button1}
          locations={[0, 1]}
          colors={["#fefae0", "#fb8500"]}
        >
          <Text style={[styles.tmKim, styles.sCuLayout]}>Tìm kiếm</Text>
          <Image
            style={[styles.searchIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/search1.png")}
          />
        </LinearGradient>
        <LinearGradient
          style={styles.button1}
          locations={[0, 1]}
          colors={["#fefae0", "#fb8500"]}
        >
          <Text style={[styles.sCu, styles.sCuLayout]}>Lịch sử</Text>
          <Image
            style={[styles.knowledgeSharingIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/time-machine1.png")}
          />
        </LinearGradient>
      </View>
      <Image
        style={styles.removeBgai17246349132062Icon}
        contentFit="cover"
        source={require("../assets/removebgai-1724634913206-2.png")}
      />
      <View style={styles.text}>
        <Text style={[styles.rnCNuContainer, styles.sCuLayout]}>
          <Text style={styles.rnCNuContainer1}>
            <Text style={styles.rnC}>{`Rắn độc
`}</Text>
            <Text
              style={styles.nuBRn}
            >{`Nếu bị rắn độc cắn, hành động nhanh chóng và chính xác là rất quan trọng:
Gọi cấp cứu: Ngay lập tức gọi cấp cứu hoặc đưa người bị cắn đến bệnh viện.
Giữ bình tĩnh: Cố gắng giữ bình tĩnh để giảm tốc độ tim và hạn chế di chuyển.
Giữ vị trí cắn ở vị trí thấp hơn tim: Điều này có thể giúp làm chậm sự lan truyền của nọc độc.
Cởi bỏ đồ trang sức: Nếu vùng bị cắn bị sưng, hãy cởi bỏ các trang sức (như nhẫn, đồng hồ) để tránh chèn ép.

`}</Text>
            <Text style={styles.rnC}>{`
Không làm những việc sau:
`}</Text>
            <Text style={styles.nuBRn}>{`Không chích hoặc hút nọc độc ra.
Không băng chặt vết thương, vì điều này có thể làm giảm lưu thông máu.
Không uống rượu hoặc caffeine, vì chúng có thể làm tăng tốc độ lưu thông máu.
Không sử dụng kem bôi hoặc thuốc kháng sinh.`}</Text>
          </Text>
        </Text>
      </View>
      <Text style={styles.sCuKhi}>Sơ cứu khi bị rắn cắn</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  sCuLayout: {
    display: "flex",
    lineHeight: 20,
    letterSpacing: 0,
    alignItems: "center",
  },
  iconLayout: {
    height: 17,
    width: 17,
    top: 11,
    position: "absolute",
  },
  sCu: {
    left: 38,
    width: 52,
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.m3LabelLarge,
    fontWeight: "500",
    fontSize: FontSize.m3LabelLarge_size,
    top: 0,
    display: "flex",
    lineHeight: 20,
    letterSpacing: 0,
    height: 39,
    justifyContent: "center",
    position: "absolute",
  },
  knowledgeSharingIcon: {
    left: 21,
  },
  button1: {
    borderRadius: Border.br_81xl,
    width: 110,
    backgroundColor: "transparent",
    height: 39,
  },
  tmKim: {
    left: 32,
    width: 63,
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.m3LabelLarge,
    fontWeight: "500",
    fontSize: FontSize.m3LabelLarge_size,
    top: 0,
    display: "flex",
    lineHeight: 20,
    letterSpacing: 0,
    height: 39,
    justifyContent: "center",
    position: "absolute",
  },
  searchIcon: {
    left: 15,
  },
  button1Parent: {
    top: 847,
    left: -3,
    backgroundColor: Color.colorPalegoldenrod,
    width: 415,
    height: 70,
    gap: Gap.gap_md,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    position: "absolute",
  },
  removeBgai17246349132062Icon: {
    top: 59,
    left: 0,
    width: 137,
    height: 91,
    position: "absolute",
  },
  rnC: {
    fontWeight: "700",
    fontFamily: FontFamily.robotoFlex,
  },
  nuBRn: {
    fontFamily: FontFamily.robotoFlexRegular,
  },
  rnCNuContainer1: {
    width: "100%",
  },
  rnCNuContainer: {
    fontSize: FontSize.size_xl,
    color: Color.subtleDark,
    width: 377,
    height: 406,
    textAlign: "left",
    display: "flex",
    lineHeight: 20,
    letterSpacing: 0,
  },
  text: {
    top: 295,
    left: 28,
    width: 350,
    height: 267,
    flexDirection: "row",
    position: "absolute",
  },
  sCuKhi: {
    marginLeft: -126,
    bottom: 753,
    left: "50%",
    fontSize: FontSize.size_11xl,
    fontFamily: FontFamily.rasaRegular,
    color: Color.colorBlack,
    width: 254,
    height: 29,
    textAlign: "left",
    position: "absolute",
  },
  nhnBitSCu2: {
    backgroundColor: Color.colorCornsilk,
    flex: 1,
    height: 917,
    overflow: "hidden",
    width: "100%",
  },
});

export default NhnBitSCu1;
