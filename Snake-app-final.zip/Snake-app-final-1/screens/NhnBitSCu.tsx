import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Border, Gap } from "../GlobalStyles";

const NhnBitSCu = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <Pressable
      style={styles.nhnBitSCu1}
      onPress={() => navigation.navigate("NhnBitSCu1")}
    >
      <View style={styles.button1Parent}>
        <LinearGradient
          style={styles.button1}
          locations={[0, 1]}
          colors={["#fefae0", "#fb8500"]}
        >
          <Text style={[styles.sCu, styles.sCuLayout]}>{`Sơ cứu `}</Text>
          <Image
            style={[styles.knowledgeSharingIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/knowledge-sharing.png")}
          />
        </LinearGradient>
        <LinearGradient
          style={styles.button1}
          locations={[0, 1]}
          colors={["#fefae0", "#fb8500"]}
        >
          <Text style={[styles.tmKim, styles.lchSTypo]}>Tìm kiếm</Text>
          <Image
            style={[styles.searchIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/search.png")}
          />
        </LinearGradient>
        <LinearGradient
          style={styles.button1}
          locations={[0, 1]}
          colors={["#fefae0", "#fb8500"]}
        >
          <Text style={[styles.lchS, styles.lchSTypo]}>Lịch sử</Text>
          <Image
            style={[styles.knowledgeSharingIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/time-machine.png")}
          />
        </LinearGradient>
      </View>
      <Image
        style={styles.removeBgai17246349132062Icon}
        contentFit="cover"
        source={require("../assets/removebgai-1724634913206-2.png")}
      />
      <Image
        style={styles.nhNhnDin1}
        contentFit="cover"
        source={require("../assets/nh-nhn-din-1.png")}
      />
      <View style={styles.text}>
        <Text style={[styles.rnKhngCContainer, styles.sCuLayout1]}>
          <Text style={styles.rnKhngCContainer1}>
            <Text style={styles.rnKhngC}>{`Rắn không độc
`}</Text>
            <Text
              style={styles.nuBRn}
            >{`Nếu bị rắn không độc cắn, các bước sơ cứu như sau:
Giữ bình tĩnh: Cố gắng không hoảng sợ để giữ nhịp tim ổn định.
Rửa vết thương: Rửa sạch vết cắn bằng xà phòng và nước để loại bỏ bất kỳ bụi bẩn nào.
Ngừng hoạt động: Ngồi hoặc nằm xuống để hạn chế vận động, giúp giảm nguy cơ sưng tấy.
Băng vết thương: Sử dụng băng sạch để băng vết thương.
Theo dõi tình trạng: Theo dõi xem có dấu hiệu nhiễm trùng hay không (đỏ, sưng, đau) và đi khám bác sĩ nếu cần.`}</Text>
          </Text>
        </Text>
      </View>
      <Text style={styles.sCuKhi}>Sơ cứu khi bị rắn cắn</Text>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  sCuLayout: {
    width: 52,
    left: 38,
  },
  iconLayout: {
    height: 17,
    width: 17,
    top: 11,
    position: "absolute",
  },
  lchSTypo: {
    fontFamily: FontFamily.m3LabelLarge,
    fontWeight: "500",
    display: "flex",
    textAlign: "center",
    color: Color.colorWhite,
    lineHeight: 20,
    letterSpacing: 0,
    fontSize: FontSize.m3LabelLarge_size,
    top: 0,
    height: 39,
    justifyContent: "center",
    alignItems: "center",
    position: "absolute",
  },
  sCuLayout1: {
    display: "flex",
    lineHeight: 20,
    letterSpacing: 0,
    alignItems: "center",
  },
  sCu: {
    fontFamily: FontFamily.robotoBold,
    display: "flex",
    lineHeight: 20,
    letterSpacing: 0,
    alignItems: "center",
    textAlign: "center",
    color: Color.colorWhite,
    fontSize: FontSize.m3LabelLarge_size,
    top: 0,
    width: 52,
    fontWeight: "700",
    left: 38,
    height: 39,
    justifyContent: "center",
    position: "absolute",
  },
  knowledgeSharingIcon: {
    left: 21,
  },
  button1: {
    borderRadius: Border.br_81xl,
    width: 110,
    backgroundColor: "transparent",
    height: 39,
  },
  tmKim: {
    left: 32,
    width: 63,
  },
  searchIcon: {
    left: 15,
  },
  lchS: {
    width: 52,
    left: 38,
    fontWeight: "500",
  },
  button1Parent: {
    bottom: 0,
    backgroundColor: Color.colorPalegoldenrod,
    width: 412,
    height: 70,
    gap: Gap.gap_md,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    left: 0,
    position: "absolute",
  },
  removeBgai17246349132062Icon: {
    top: 59,
    width: 137,
    height: 91,
    left: 0,
    position: "absolute",
  },
  nhNhnDin1: {
    top: 179,
    left: 128,
    width: 169,
    height: 243,
    position: "absolute",
  },
  rnKhngC: {
    fontFamily: FontFamily.robotoFlex,
    fontWeight: "700",
  },
  nuBRn: {
    fontFamily: FontFamily.robotoFlexRegular,
  },
  rnKhngCContainer1: {
    width: "100%",
  },
  rnKhngCContainer: {
    fontSize: FontSize.size_xl,
    color: Color.subtleDark,
    width: 344,
    height: 351,
    textAlign: "left",
    display: "flex",
    lineHeight: 20,
    letterSpacing: 0,
  },
  text: {
    top: 439,
    left: 48,
    width: 295,
    height: 27,
    flexDirection: "row",
    position: "absolute",
  },
  sCuKhi: {
    marginLeft: -126,
    bottom: 753,
    left: "50%",
    fontSize: FontSize.size_11xl,
    fontFamily: FontFamily.rasaRegular,
    color: Color.colorBlack,
    width: 254,
    height: 29,
    textAlign: "left",
    position: "absolute",
  },
  nhnBitSCu1: {
    backgroundColor: Color.colorCornsilk,
    flex: 1,
    height: 917,
    width: "100%",
  },
});

export default NhnBitSCu;
