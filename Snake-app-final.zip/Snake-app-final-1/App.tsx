const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { useFonts } from "expo-font";
import Page from "./screens/Page";
import Page2giiThiuApp from "./screens/Page2giiThiuApp";
import NhnBitSCu from "./screens/NhnBitSCu";
import LchSTmKim from "./screens/LchSTmKim";
import XemLiTLchS from "./screens/XemLiTLchS";
import TmKimThngTin from "./screens/TmKimThngTin";
import TmKimThngTin1 from "./screens/TmKimThngTin1";
import NhnBitSCu1 from "./screens/NhnBitSCu1";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  const [fontsLoaded, error] = useFonts({
    "Inter-Regular": require("./assets/fonts/Inter-Regular.ttf"),
    "Inter-Bold": require("./assets/fonts/Inter-Bold.ttf"),
    "Rasa-Regular": require("./assets/fonts/Rasa-Regular.ttf"),
    "Rasa-Bold": require("./assets/fonts/Rasa-Bold.ttf"),
    "Roboto-Medium": require("./assets/fonts/Roboto-Medium.ttf"),
    "Roboto-Bold": require("./assets/fonts/Roboto-Bold.ttf"),
    "RobotoFlex-Regular": require("./assets/fonts/RobotoFlex-Regular.ttf"),
    "RedactedScript-Regular": require("./assets/fonts/RedactedScript-Regular.ttf"),
  });

  if (!fontsLoaded && !error) {
    return null;
  }

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen
              name="Page"
              component={Page}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Page2giiThiuApp"
              component={Page2giiThiuApp}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="NhnBitSCu"
              component={NhnBitSCu}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="LchSTmKim"
              component={LchSTmKim}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="XemLiTLchS"
              component={XemLiTLchS}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="TmKimThngTin"
              component={TmKimThngTin}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="TmKimThngTin1"
              component={TmKimThngTin1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="NhnBitSCu1"
              component={NhnBitSCu1}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
    </>
  );
};
export default App;
